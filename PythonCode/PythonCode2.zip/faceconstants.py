facepairs_female = ["F03","F04","F05","F07","F08","F10","F11","F12","F13","F17","F18","F22","F23","F24","F28","F29","F34","F35"]
facepairs_male = ["M01","M02","M04","M06","M08","M09","M10","M14","M17","M18","M24","M25","M26","M28","M30","M31","M34","M35"]

#female_folder = "C:\Users\ITLab\Desktop\KaelaTerneProject\WinPython-PyGaze-0.6.0\Female\\"
#male_folder = 	"C:\Users\ITLab\Desktop\KaelaTerneProject\WinPython-PyGaze-0.6.0\male\\"

female_folder = "C:\\Users\\Tom\\Desktop\\PythonCode\\Female\\"
male_folder = 	"C:\\Users\\Tom\\Desktop\\PythonCode\\male\\"

happy_suffix = "HA"
neutral_suffix = "NE"
sad_suffix = "SA"

regular_suffix = "_resi.jpg"
circle_suffix = "_result_circle.jpg"
square_suffix = "_result_square.jpg"
